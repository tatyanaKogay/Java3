package ru.gb.j_two.chat.server.core;

public interface ChatServerListener {
    void onChatServerMessage(String msg);
}
